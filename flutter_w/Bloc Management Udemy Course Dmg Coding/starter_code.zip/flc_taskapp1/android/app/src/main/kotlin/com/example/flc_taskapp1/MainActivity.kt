package com.example.flc_taskapp1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
