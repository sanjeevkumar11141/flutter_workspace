// import 'package:e_commerce_app/constants/style_constant.dart';
// import 'package:e_commerce_app/presentation/screens/forgot_password/widgets/forgot_pass_form.dart';
// import 'package:flutter/material.dart';

// import 'package:e_commerce_app/configs/size_config.dart';

// class Body extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: SizedBox(
//         width: double.infinity,
//         child: Padding(
//           padding: EdgeInsets.symmetric(horizontal: 20),
//           child: SingleChildScrollView(
//             child: Column(
//               children: [
//                 SizedBox(height: SizeConfig.screenHeight * 0.04),
//                 Text(
//                   "Forgot Password",
//                   style: headingStyle(),
//                 ),
//                 Text(
//                   "Don't worry! Please enter your email \nWe will send you a link to return to your account",
//                   textAlign: TextAlign.center,
//                 ),
//                 SizedBox(height: SizeConfig.screenHeight * 0.08),
//                 ForgotPassForm(),
//                 SizedBox(height: SizeConfig.screenHeight * 0.04),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
